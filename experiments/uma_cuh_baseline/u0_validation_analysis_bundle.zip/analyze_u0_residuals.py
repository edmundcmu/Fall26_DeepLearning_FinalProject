#!/usr/bin/env python3
"""Analyze existing UMA predictions against SRP48-DFT validation labels.

No model inference, gradient computation, GPU, fine-tuning or test-set access.
Run:
 python analyze_u0_residuals.py --structures structures.extxyz \
   --predictions val_predictions.npz --metrics metrics.json --out u0_analysis

The EXTXYZ reader intentionally supports the pinned Cu/H export's specific
Properties=species:S:1:pos:R:3:forces:R:3 layout. If format changes, adapt reader.
All geometric distances use periodic minimum-image search for the given cells.
"""
import argparse
import csv
import json
import shlex
from pathlib import Path
from itertools import product

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np


def load_xyz(path):
    frames = []
    with open(path, encoding='utf-8') as fh:
        while True:
            first = fh.readline()
            if not first:
                break
            n = int(first.strip())
            header = {}
            for token in shlex.split(fh.readline()):
                if '=' in token:
                    key, value = token.split('=', 1)
                    header[key] = value
            prop = header.get('Properties')
            if prop != 'species:S:1:pos:R:3:forces:R:3':
                raise ValueError(f'Unsupported EXTXYZ Properties layout: {prop}')
            symbols, coords, forces = [], [], []
            for _ in range(n):
                fields = fh.readline().split()
                symbols.append(fields[0])
                coords.append([float(x) for x in fields[1:4]])
                forces.append([float(x) for x in fields[4:7]])
            frames.append({
                'source_index': int(header['source_index']),
                'symbols': np.asarray(symbols),
                'coords': np.asarray(coords),
                'forces': np.asarray(forces),
                'energy': float(header['energy']),
                'cell': np.asarray([float(x) for x in header['Lattice'].split()]).reshape(3, 3),
                'pbc': tuple(s.upper() == 'T' for s in header['pbc'].split()),
            })
    return frames


def distance_pbc(a, b, cell, pbc):
    """Shortest image distance with local 3x3x3 lattice-image search."""
    frac = (np.asarray(a) - np.asarray(b)) @ np.linalg.inv(cell)
    center = np.rint(frac)
    centers = [(-1, 0, 1) if periodic else (0,) for periodic in pbc]
    distances = []
    for shift in product(*centers):
        n = center * np.asarray(pbc, dtype=int) + np.asarray(shift)
        distances.append(np.linalg.norm((frac - n) @ cell))
    return float(min(distances))


def smart_parity(ax, actual, predicted, title, unit, density=False):
    if density:
        ax.hexbin(actual, predicted, gridsize=58, mincnt=1, bins='log', linewidths=0)
    else:
        ax.scatter(actual, predicted, s=14, alpha=0.55, rasterized=True)
    lo = float(min(np.min(actual), np.min(predicted)))
    hi = float(max(np.max(actual), np.max(predicted)))
    pad = 0.04 * (hi - lo) if hi > lo else 1.0
    lo, hi = lo-pad, hi+pad
    ax.plot([lo, hi], [lo, hi], 'k--', lw=1)
    ax.set_xlim(lo, hi)
    ax.set_ylim(lo, hi)
    ax.set_xlabel(f'DFT ({unit})')
    ax.set_ylabel(f'UMA U0 ({unit})')
    ax.set_title(title, fontsize=11)
    ax.grid(alpha=0.13)


def savefig(fig, out, name):
    fig.savefig(out / name, dpi=210, bbox_inches='tight')
    plt.close(fig)


def analyze(args):
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    frames = load_xyz(args.structures)
    with np.load(args.predictions) as pred:
        Euma = pred['energy'].copy()
        Fuma = pred['forces'].copy()
        offsets = pred['offsets'].copy()
        source_ids = pred['source_index'].copy()
    with open(args.metrics, encoding='utf-8') as f:
        metrics = json.load(f)
    n = len(frames)
    assert n == len(Euma) == len(source_ids) == int(metrics['n_configurations'])
    assert np.array_equal(source_ids, [f['source_index'] for f in frames]), 'source_index mismatch'
    assert np.array_equal(offsets, np.r_[0, np.cumsum([len(f['symbols']) for f in frames])]), 'force offsets mismatch'
    assert len(Fuma) == int(offsets[-1])

    E_dft = np.array([f['energy'] for f in frames])
    compositions = np.array(['H2Cu54' if np.count_nonzero(f['symbols'] == 'H') == 2 else 'Cu54' for f in frames])
    assert set(compositions) == {'Cu54', 'H2Cu54'}
    offset_train = np.array([metrics['energy_offsets_fit_on_train_eV'][s] for s in compositions])
    Ealigned = Euma - offset_train
    residual = Euma - E_dft
    residual_aligned = Ealigned - E_dft

    h_err, cu_err, h_rmse, cu_rmse = [], [], [], []
    hh, hcu = [], []
    hdf, hpr, cdf, cpr = [], [], [], []
    rows = []
    for i, frame in enumerate(frames):
        lo, hi = offsets[i:i+2]
        F_ref = frame['forces']
        F_pred = Fuma[lo:hi]
        mask_h = frame['symbols'] == 'H'
        if not np.array_equal(frame['symbols'][~mask_h], np.repeat('Cu', np.count_nonzero(~mask_h))):
            raise ValueError('Unexpected non-Cu/non-H species')
        df = F_pred-F_ref
        cu_err_i = float(np.mean(np.abs(df[~mask_h])))
        cu_rmse_i = float(np.sqrt(np.mean(df[~mask_h]**2)))
        cdf.extend(F_ref[~mask_h].ravel()); cpr.extend(F_pred[~mask_h].ravel())
        cu_err.append(cu_err_i);cu_rmse.append(cu_rmse_i)
        if mask_h.any():
            h_err_i = float(np.mean(np.abs(df[mask_h])))
            h_rmse_i = float(np.sqrt(np.mean(df[mask_h]**2)))
            hdf.extend(F_ref[mask_h].ravel());hpr.extend(F_pred[mask_h].ravel())
            Hcoord=frame['coords'][mask_h]
            Cucord=frame['coords'][~mask_h]
            d_hh = distance_pbc(Hcoord[0],Hcoord[1], frame['cell'],frame['pbc'])
            d_hcu = min(distance_pbc(h, c, frame['cell'],frame['pbc']) for h in Hcoord for c in Cucord)
        else:
            h_err_i=h_rmse_i=d_hh=d_hcu=float('nan')
        h_err.append(h_err_i);h_rmse.append(h_rmse_i);hh.append(d_hh);hcu.append(d_hcu)
        rows.append({
            'source_index': int(frame['source_index']),
            'composition': str(compositions[i]),
            'E_DFT_eV': E_dft[i],
            'E_UMA_eV': Euma[i],
            'energy_residual_raw_eV': residual[i],
            'energy_residual_train_aligned_eV': residual_aligned[i],
            'H_force_MAE_eV_per_A': h_err_i,
            'H_force_RMSE_eV_per_A': h_rmse_i,
            'Cu_force_MAE_eV_per_A': cu_err_i,
            'Cu_force_RMSE_eV_per_A': cu_rmse_i,
            'H_H_distance_A': d_hh,
            'nearest_H_Cu_distance_A': d_hcu
        })
    h_err=np.asarray(h_err); cu_err=np.asarray(cu_err)
    hh=np.asarray(hh);hcu=np.asarray(hcu)
    hf=np.isfinite(h_err)
    hdf=np.asarray(hdf);hpr=np.asarray(hpr);cdf=np.asarray(cdf);cpr=np.asarray(cpr)
    assert np.isclose(np.mean(np.abs(hdf-hpr)),metrics['forces']['H']['mae_eV_per_A'], rtol=1e-7)
    assert np.isclose(np.mean(np.abs(cdf-cpr)),metrics['forces']['Cu']['mae_eV_per_A'], rtol=1e-7)
    assert np.isclose(np.mean(np.abs(residual)),metrics['raw_energy_mae_eV_per_configuration'],rtol=1e-7)
    assert np.isclose(np.mean(np.abs(residual_aligned)),metrics['train_offset_aligned_energy_mae_eV_per_configuration'],rtol=1e-7)

    with open(out / 'per_configuration.csv', 'w', newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

    # Figure 1 -- raw/aligned energy parity + per-composition residuals
    fig,axes=plt.subplots(1,3,figsize=(15.0,4.7),layout='constrained')
    for s in ['H2Cu54','Cu54']:
        sel=compositions==s
        axes[0].scatter(E_dft[sel],Euma[sel],s=25,alpha=0.7,label=f'{s} (n={sel.sum()})')
        axes[1].scatter(E_dft[sel],Ealigned[sel],s=25,alpha=0.7,label=s)
        axes[2].scatter(np.repeat(s,sel.sum()),residual[sel],s=21,alpha=.6)
        axes[2].scatter(np.repeat(s+' aligned',sel.sum()),residual_aligned[sel],s=21,alpha=.6)
    for ax, predx, title in [(axes[0],Euma,'Raw UMA energy'),(axes[1],Ealigned,'Training-offset-aligned UMA energy')]:
        lo=min(E_dft.min(),predx.min());hi=max(E_dft.max(),predx.max());pad=.035*(hi-lo)
        ax.plot([lo-pad,hi+pad],[lo-pad,hi+pad],'k--',lw=1)
        ax.set(xlim=(lo-pad,hi+pad),ylim=(lo-pad,hi+pad),xlabel='DFT energy (eV)',ylabel='UMA energy (eV)',title=title)
        ax.legend(fontsize=8);ax.grid(alpha=.13)
    axes[2].axhline(0,color='k',ls='--',lw=1)
    axes[2].set(title='Signed energy residual (UMA - DFT)',ylabel='Residual (eV)')
    axes[2].tick_params(axis='x',labelrotation=40,labelsize=8)
    axes[2].grid(alpha=.13)
    savefig(fig,out,'01_energy_parity.png')

    # Figure 2 -- H and Cu force parity
    fig,axes=plt.subplots(1,2,figsize=(11.8,5.15),layout='constrained')
    smart_parity(axes[0],hdf,hpr,f'H Cartesian forces | MAE {np.mean(abs(hdf-hpr)):.4f} eV/Å','eV/Å')
    smart_parity(axes[1],cdf,cpr,f'Cu Cartesian forces | MAE {np.mean(abs(cdf-cpr)):.4f} eV/Å','eV/Å',density=True)
    savefig(fig,out,'02_force_parity.png')

    # Figure 3 -- distribution and H outliers
    fig,axes=plt.subplots(1,3,figsize=(15,4.5),layout='constrained')
    axes[0].hist(h_err[hf],bins=17,alpha=.7,label='H (64 frames)')
    axes[0].hist(cu_err,bins=17,alpha=.7,label='Cu (100 frames)')
    axes[0].set(xlabel='Per-frame component force MAE (eV/Å)',ylabel='Count',title='Force MAE distributions')
    axes[0].legend(fontsize=9)
    s=np.sort(h_err[hf]);axes[1].scatter(np.arange(1,len(s)+1),s,s=20)
    axes[1].axhline(np.mean(s),ls='--',color='k',lw=1,label=f'Mean {np.mean(s):.4f}')
    axes[1].set(title='H force MAE, sorted by configuration',xlabel='Sorted H-containing configuration',ylabel='H MAE (eV/Å)')
    axes[1].legend(fontsize=9)
    top=np.argsort(-h_err[hf])[:10]; idx=np.where(hf)[0][top]
    axes[2].barh([str(frames[i]['source_index']) for i in idx[::-1]],h_err[idx[::-1]])
    axes[2].set(title='Largest H force-error configurations',xlabel='H force MAE (eV/Å)',ylabel='Original source index')
    for ax in axes:ax.grid(alpha=.13)
    savefig(fig,out,'03_force_outliers.png')

    # Figure 4 -- geometry correlation and predefined bins
    fig,axes=plt.subplots(1,3,figsize=(15,4.5),layout='constrained')
    axes[0].scatter(hh[hf],h_err[hf],alpha=.7,s=28)
    axes[0].set(xlabel='H–H minimum-image distance (Å)',ylabel='H force MAE (eV/Å)',title='Force error vs H–H separation')
    axes[1].scatter(hcu[hf],h_err[hf],alpha=.7,s=28)
    axes[1].set(xlabel='Closest H–Cu distance (Å)',ylabel='H force MAE (eV/Å)',title='Force error vs nearest Cu')
    bins=[0,0.9,1.6,np.inf]
    labels=['<0.9','0.9–1.6','≥1.6']
    vals=[];counts=[]
    for x,y in zip(bins[:-1],bins[1:]):
        use=hf&(hh>=x)&(hh<y)
        vals.append(np.mean(h_err[use]) if use.any() else np.nan)
        counts.append(int(use.sum()))
    axes[2].bar(labels,vals)
    for j,(v,nj) in enumerate(zip(vals,counts)):
        axes[2].text(j,v+.0006,f'n={nj}',ha='center',fontsize=9)
    axes[2].set(title='H force error by H–H distance bin',xlabel='H–H distance (Å)',ylabel='Mean H force MAE (eV/Å)')
    for ax in axes:ax.grid(alpha=.13)
    savefig(fig,out,'04_H_geometry_dependence.png')

    # Figure 5 -- SAME-COMPOSITION relative-energy differences
    fig,axes=plt.subplots(1,3,figsize=(15.0,4.8),layout='constrained')
    pairs={}
    for s in ('H2Cu54','Cu54'):
        sel=compositions==s
        ref=E_dft[sel]; pre=Euma[sel]
        ids=np.triu_indices(len(ref),1)
        r=(ref[:,None]-ref[None,:])[ids]
        p=(pre[:,None]-pre[None,:])[ids]
        pairs[s]=(r,p)
        axes[0].scatter(r,p,s=5,alpha=.20,label=f'{s}: {len(r)} pairs',rasterized=True)
        axes[1].hist(p-r,bins=45,alpha=.60,label=f'{s}: MAE {np.mean(abs(p-r)):.3f} eV')
        axes[2].scatter(r,p-r,s=5,alpha=.22,label=s,rasterized=True)
    for ax in axes:ax.grid(alpha=.13)
    lo=min(min(r.min(),p.min()) for r,p in pairs.values());hi=max(max(r.max(),p.max()) for r,p in pairs.values())
    axes[0].plot([lo,hi],[lo,hi],'k--',lw=1)
    axes[0].set(xlabel='DFT ΔE(B−A) (eV)',ylabel='UMA ΔE(B−A) (eV)',title='Pairwise relative-energy parity')
    axes[0].legend(fontsize=8)
    axes[1].axvline(0,ls='--',color='k',lw=1)
    axes[1].set(xlabel='Error in ΔE (eV)',ylabel='Pair count',title='Error in relative energies')
    axes[1].legend(fontsize=8)
    axes[2].axhline(0,ls='--',color='k',lw=1)
    axes[2].set(xlabel='DFT ΔE(B−A) (eV)',ylabel='UMA ΔE − DFT ΔE (eV)',title='Pair error vs reference energy')
    savefig(fig,out,'05_relative_energy.png')

    summary={
        'evaluation_split': metrics['split'],
        'n_val':n,
        'H_containing_frames':int(hf.sum()),
        'Cu_only_frames':int((~hf).sum()),
        'raw_total_energy_mae_eV_per_config':float(np.mean(np.abs(residual))),
        'train_aligned_total_energy_mae_eV_per_config':float(np.mean(np.abs(residual_aligned))),
        'force_H_component_mae_eV_per_A':float(np.mean(np.abs(hdf-hpr))),
        'force_Cu_component_mae_eV_per_A':float(np.mean(np.abs(cdf-cpr))),
        'H_force_mae_per_frame_median':float(np.median(h_err[hf])),
        'H_force_mae_per_frame_p90':float(np.percentile(h_err[hf],90)),
        'H_force_mae_top10_share_of_total_H_error':float(np.sum(np.sort(h_err[hf])[-10:])/np.sum(h_err[hf])),
        'H_H_distance_vs_H_mae_pearson':float(np.corrcoef(hh[hf],h_err[hf])[0,1]),
        'H_Cu_distance_vs_H_mae_pearson':float(np.corrcoef(hcu[hf],h_err[hf])[0,1]),
        'H_bond_distance_bins_A':{lab:{'n':c,'mean_H_component_mae_eV_per_A':float(v)} for lab,c,v in zip(labels,counts,vals)},
        'composition':{},
        'relative_energy_definition':'All unordered pairs of distinct validation configurations WITHIN each composition, ΔE=E_B-E_A; pairs share configurations and are NOT independent observations',
        'geometry_definition':'H-H distance and closest H-Cu distance use minimum-image convention on the stored periodic cell',
    }
    for s in ['H2Cu54','Cu54']:
        sel=compositions==s
        r,p=pairs[s]
        summary['composition'][s]={
            'n':int(sel.sum()),
            'raw_E_MAE_eV':float(np.mean(np.abs(residual[sel]))),
            'aligned_E_MAE_eV':float(np.mean(np.abs(residual_aligned[sel]))),
            'raw_E_mean_signed_error_eV':float(np.mean(residual[sel])),
            'aligned_E_mean_signed_error_eV':float(np.mean(residual_aligned[sel])),
            'raw_E_residual_std_eV':float(np.std(residual[sel])),
            'pair_count':len(r),
            'pairwise_deltaE_MAE_eV':float(np.mean(np.abs(p-r))),
            'pairwise_deltaE_RMSE_eV':float(np.sqrt(np.mean((p-r)**2))),
            'pairwise_deltaE_pearson_correlation':float(np.corrcoef(r,p)[0,1]),
        }
    with open(out/'summary.json','w') as f:json.dump(summary,f,indent=2)
    print(json.dumps(summary,indent=2))
    print(f'Plots and per-configuration CSV written to: {out.resolve()}')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--structures',default='structures.extxyz')
    parser.add_argument('--predictions',default='val_predictions.npz')
    parser.add_argument('--metrics',default='metrics.json')
    parser.add_argument('--out',default='u0_analysis')
    analyze(parser.parse_args())
if __name__=='__main__':main()
