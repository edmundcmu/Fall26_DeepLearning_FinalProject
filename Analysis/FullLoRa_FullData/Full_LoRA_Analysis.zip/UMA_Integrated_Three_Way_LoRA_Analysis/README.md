# DFT / Frozen UMA U0 / Full LoRA three-way Cu-H comparison

## Deliverables

- `DFT_U0_Full_LoRA_Integrated_Report.pdf`: ten-page, English, report-ready quantitative analysis.
- `analysis_zh_TW.md`: Traditional Chinese explanations, interpretations, cautions, and copy-ready English results paragraph.
- `figures/`: 13 figures. Eleven original three-way plots in PNG/vector PDF, plus the two original Full-LoRA training/budget plots in PNG (reproducible as PNG/vector PDF).
- `tables/`: per-configuration energies/MAEs, per-atom DFT/U0/LoRA force vectors, MAE/RMSE, bootstrap intervals, composition-specific metrics and training history.
- `source_data/`: the *validation-only* DFT extxyz labels, U0 and LoRA prediction arrays, training log, calibration and source manifest used to generate the comparison. No held-out test structures are included.
- `source/reproduce_analysis.py`: regenerate plots and derived tables from `source_data`.
- `source/build_report.py`: regenerate the 10-page PDF report from existing figures/tables.
- `source/reproduce_training_budget.py`: regenerate detailed training-convergence and six-group budget plots from `tables/training_history.csv` and `tables/adapter_parameters.csv`.

## Reproduce

From this folder, with Python 3 and `numpy`, `pandas`, `matplotlib`, `scipy`, `reportlab`, `pillow` installed:

```bash
python source/reproduce_analysis.py
python source/reproduce_training_budget.py
python source/build_report.py
```

The analysis directly checks the DFT extxyz checksum against `source_data/manifest.json`, matches 100 `source_index` entries across DFT/U0/LoRA, and verifies the expected force-array segmentation. It then checks all four MAEs against the original submitted LoRA validation metrics. No inference, DFT calculations, GPU or network access is needed.

## Precision and protocol

- Validation: 100 frames (36 Cu54 and 64 Cu54H2).
- Atomic forces are aligned by source index and atomic order; error metrics are Cartesian-component MAEs, **not** force-vector magnitude MAEs.
- Energy calibration uses *only* offsets fitted on U0 training predictions, not validation data.
- The original frozen U0 predictions and Full LoRA predictions come from different forward inference runs but identical validation configurations.
- The DFT values are the numerical reference, not a model with a measured zero-error generalization score.
- Bootstrap intervals are exploratory due to possible trajectory correlation and checkpoint selection on validation.
- The 200-frame test split remains unopened.
