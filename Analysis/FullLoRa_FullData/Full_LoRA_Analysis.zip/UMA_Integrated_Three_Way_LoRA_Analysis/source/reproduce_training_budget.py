"""Reproduce the detailed training-loss and six-group budget figures.

Usage: python source/reproduce_training_budget.py
Inputs: tables/training_history.csv, tables/adapter_parameters.csv
No GPU, UMA checkpoint, or model inference is required.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / 'figures'
TAB = ROOT / 'tables'
FIG.mkdir(parents=True, exist_ok=True)
df = pd.read_csv(TAB / 'training_history.csv')
gc = pd.read_csv(TAB / 'adapter_parameters.csv')

plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 10.5,
    'axes.titlesize': 14, 'axes.labelsize': 11,
    'axes.spines.top': False, 'axes.spines.right': False,
    'savefig.facecolor': 'white', 'axes.grid': True,
    'grid.alpha': 0.18, 'figure.dpi': 140,
})

def save(fig, base):
    fig.savefig(FIG / f'{base}.png', dpi=240, bbox_inches='tight', pad_inches=.14)
    fig.savefig(FIG / f'{base}.pdf', bbox_inches='tight', pad_inches=.14)
    plt.close(fig)

# Training convergence: preserve original Full-LoRA figure presentation.
fig, ax = plt.subplots(figsize=(8.5, 4.25))
steps = df.step.to_numpy()
loss = df.train_loss.to_numpy()
roll = df.train_loss.rolling(101, center=True, min_periods=30)
ax.scatter(steps, loss, s=5, alpha=.17,
           label='Individual updates (batch size 1)', rasterized=True)
ax.plot(steps, roll.median(), linewidth=2.3,
        label='Rolling median (101 updates)')
ax.plot(steps, roll.quantile(.9), linewidth=1.35, linestyle='--',
        label='Rolling 90th percentile')
for update in (500, 1000, 1500):
    ax.axvline(update, linestyle=':', linewidth=.85, alpha=.5)
ax.set_yscale('log')
ax.set_xlim(1, 2000)
ax.set_xlabel('Optimizer update')
ax.set_ylabel('Normalized training objective (log scale)')
ax.set_title('Training loss decreases despite sample-to-sample fluctuations',
             loc='left', pad=12)
ax.legend(loc='upper right', frameon=False, fontsize=8.7)
fig.tight_layout()
save(fig, '12_detailed_training_loss')

# Parameter-budget figure: computed from saved LoRA tensor counts.
groups = ['R_early', 'R_late', 'S_early', 'S_late', 'A_early', 'A_late']
group_count = dict(zip(gc.group, gc.trainable_parameters))
counts = np.array([group_count[k] for k in groups])
assert counts.sum() == 343040
fig, ax = plt.subplots(figsize=(8.5, 4.2))
y = np.arange(len(groups))
ax.barh(y, counts)
ax.set_yticks(y, groups)
ax.invert_yaxis()
ax.set_xlim(0, 117000)
ax.set_xlabel('Trainable LoRA parameters')
ax.set_title('S-type groups dominate the L-All parameter budget',
             loc='left', pad=12)
for i, count in enumerate(counts):
    ax.text(count + 1700, i, f'{count:,}', va='center', fontsize=9)
ax.text(.97, .05, 'Total: 343,040 parameters; 120 adapted sites',
        transform=ax.transAxes, ha='right', fontsize=10)
fig.tight_layout()
save(fig, '13_six_group_parameter_budget')
print('Generated detailed training/budget figures from CSV inputs.')
