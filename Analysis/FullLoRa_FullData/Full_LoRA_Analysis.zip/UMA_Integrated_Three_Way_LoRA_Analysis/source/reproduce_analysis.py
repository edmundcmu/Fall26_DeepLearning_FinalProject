"""Reproduce DFT / frozen UMA U0 / L-All comparison from the uploaded archives.

Requirements: numpy, pandas, scipy, matplotlib, reportlab (for separate report script).
Only 100 LOCKED VALIDATION structures are read. The sealed 200-frame test set is not accessed.
"""
import io, json, zipfile, hashlib, re
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, PercentFormatter
from scipy.stats import pearsonr

OUT=Path(__file__).resolve().parents[1]
ROOT=OUT/'source_data'
FIG=OUT/'figures'; TAB=OUT/'tables'
for p in [FIG,TAB]:p.mkdir(exist_ok=True,parents=True)

# Source data: the original DFT reference structures from the user's i-x20.zip.
raw=(ROOT/'DFT_val_structures.extxyz').read_bytes()
manifest=json.loads((ROOT/'manifest.json').read_text())
if True:
    assert hashlib.sha256(raw).hexdigest()==manifest['file_sha256']['val']
    lines=raw.decode().splitlines(); frames=[]; pos=0
    while pos<len(lines):
        n=int(lines[pos].strip()); header=lines[pos+1]
        en=float(re.search(r'\benergy=([^ ]+)',header).group(1))
        sid=int(re.search(r'\bsource_index=(\d+)',header).group(1))
        atoms=[line.split() for line in lines[pos+2:pos+2+n]]
        assert len(atoms)==n and all(len(a)>=7 for a in atoms)
        nums=np.array([1 if a[0]=='H' else 29 for a in atoms])
        assert sum(nums==29)==54 and sum(nums==1) in (0,2)
        f=np.array([[float(x) for x in a[-3:]] for a in atoms],dtype=np.float64)
        xyz=np.array([[float(x) for x in a[1:4]] for a in atoms],dtype=np.float64)
        frames.append(dict(energy=en,forces=f,source_index=sid,numbers=nums,positions=xyz))
        pos+=n+2
    assert len(frames)==100

with np.load(ROOT/'Full_LoRA_val_predictions.npz') as npz:
    lora={k:npz[k].copy() for k in npz.files}
vm=json.loads((ROOT/'LAll_validation_metrics.json').read_text())
train=pd.DataFrame([json.loads(s) for s in (ROOT/'training.jsonl').read_text().splitlines() if s.strip()])
with np.load(ROOT/'U0_val_predictions.npz') as npz:
    u0={k:npz[k].copy() for k in npz.files}
cal=json.loads((ROOT/'calibration.json').read_text())

ids=np.array([f['source_index'] for f in frames]); sizes=np.array([len(f['numbers']) for f in frames]);
assert np.array_equal(ids,u0['source_index']) and np.array_equal(ids,lora['source_index'])
assert np.array_equal(u0['offsets'],lora['offsets'])
assert np.array_equal(u0['offsets'],np.r_[0,np.cumsum(sizes)])
assert len(train)==2000 and len(np.unique(train['step']))==2000

DFT_E=np.array([f['energy'] for f in frames]); DFT_F=np.concatenate([f['forces'] for f in frames]); NUM=np.concatenate([f['numbers'] for f in frames]);
comp=np.array(['Cu54H2' if len(f['numbers'])==56 else 'Cu54' for f in frames]);
off=np.array([cal['offsets']['54,2' if x=='Cu54H2' else '54,0'] for x in comp]);
U_E=u0['energy'];L_E=lora['energy'];U_F=u0['forces'].astype('float64');L_F=lora['forces'].astype('float64')
N_H=NUM==1;N_CU=NUM==29
assert DFT_F.shape == U_F.shape == L_F.shape == (5528,3)

TEAL='#087E85'; ORANGE='#D17B38'; SLATE='#536577'; GRAY='#7A838D'; DARK='#202A35'; GRID='#DCE4E8'; LIGHT='#F6F9FB'
plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':11,'axes.titlesize':12,'axes.labelsize':10.5,'axes.titleweight':'bold', 'axes.edgecolor':'#B6C5CC', 'axes.spines.top':False,'axes.spines.right':False, 'xtick.color':DARK,'ytick.color':DARK,'axes.labelcolor':DARK,'text.color':DARK,'axes.grid':False,'savefig.facecolor':'white'})

def save(fig,name):
    fig.savefig(FIG/(name+'.png'),dpi=190,bbox_inches='tight',pad_inches=.15,facecolor='white')
    fig.savefig(FIG/(name+'.pdf'),bbox_inches='tight',pad_inches=.15,facecolor='white')
    plt.close(fig)

# Per frame diagnostics; energy and force means weight each composition correctly.
rows=[]; atomic_rows=[]
for i,f in enumerate(frames):
    a=u0['offsets'][i]; b=u0['offsets'][i+1]
    df=f['forces']; uf=U_F[a:b]; lf=L_F[a:b]; n=f['numbers'];
    r={'source_index':f['source_index'],'composition':comp[i], 'n_atoms':len(n),
       'DFT_energy_eV':DFT_E[i], 'U0_energy_eV':U_E[i], 'Full_LoRA_energy_eV':L_E[i],
       'U0_energy_residual_raw_eV':U_E[i]-DFT_E[i], 'Full_LoRA_energy_residual_raw_eV':L_E[i]-DFT_E[i],
       'U0_energy_residual_aligned_eV':U_E[i]-off[i]-DFT_E[i], 'Full_LoRA_energy_residual_aligned_eV':L_E[i]-off[i]-DFT_E[i]}
    for typ,t in [('H',1),('Cu',29)]:
        m=n==t
        if m.any():
            r['U0_'+typ+'_force_mae_eV_A']=np.abs(uf[m]-df[m]).mean();r['Full_LoRA_'+typ+'_force_mae_eV_A']=np.abs(lf[m]-df[m]).mean();
            r['DFT_'+typ+'_force_rms_eV_A']=np.sqrt(np.mean(df[m]**2))
        else:
            r['U0_'+typ+'_force_mae_eV_A']=np.nan;r['Full_LoRA_'+typ+'_force_mae_eV_A']=np.nan;r['DFT_'+typ+'_force_rms_eV_A']=np.nan
    rows.append(r)
    for j,(num,fd,fu,fl) in enumerate(zip(n,df,uf,lf)):
        atomic_rows.append({'source_index':f['source_index'],'composition':comp[i],'atom_index':j,'species':'H' if num==1 else 'Cu',
           'DFT_fx':fd[0],'DFT_fy':fd[1],'DFT_fz':fd[2],
           'U0_fx':fu[0],'U0_fy':fu[1],'U0_fz':fu[2],
           'Full_LoRA_fx':fl[0],'Full_LoRA_fy':fl[1],'Full_LoRA_fz':fl[2]})
per=pd.DataFrame(rows)
atomdf=pd.DataFrame(atomic_rows)
per.to_csv(TAB/'validation_per_configuration.csv',index=False)
atomdf.to_csv(TAB/'validation_per_atom_forces.csv',index=False)
train.to_csv(TAB/'training_history.csv',index=False)

# metrics and per-composition values
metrics=[]
for model,e,force in [('Frozen U0',U_E,U_F),('Full LoRA',L_E,L_F)]:
    for m_name,resid,unit in [('Raw energy MAE',e-DFT_E,'eV/config'),('Aligned energy MAE',e-off-DFT_E,'eV/config'),
                             ('H force MAE',force[N_H]-DFT_F[N_H],'eV/Å/component'),('Cu force MAE',force[N_CU]-DFT_F[N_CU],'eV/Å/component')]:
        metrics.append(dict(model=model,metric=m_name,MAE=float(np.abs(resid).mean()),RMSE=float(np.sqrt(np.mean(resid**2))),unit=unit))
metrics_df=pd.DataFrame(metrics)
metrics_df.to_csv(TAB/'validation_metric_comparison.csv',index=False)
for model,e,force,ref in [('Frozen U0',U_E,U_F,vm['U0']),('Full LoRA',L_E,L_F,vm['L_All'])]:
    vals={'energy_raw_MAE_eV':np.abs(e-DFT_E).mean(),'energy_aligned_MAE_eV':np.abs(e-off-DFT_E).mean(),
          'H_force_component_MAE_eV_per_A':np.abs(force[N_H]-DFT_F[N_H]).mean(),'Cu_force_component_MAE_eV_per_A':np.abs(force[N_CU]-DFT_F[N_CU]).mean()}
    for k,v in vals.items(): assert abs(float(v)-ref[k])<1e-12, (model,k,v,ref[k])

# paired bootstrap across configurations stratified by composition, emphasizing frame-wise independence.
rng=np.random.default_rng(41); ci=[];BB=4000
cu_idx=np.where(comp=='Cu54')[0]; h2_idx=np.where(comp=='Cu54H2')[0];
for met,u,l in [
 ('Raw energy MAE',np.abs(U_E-DFT_E),np.abs(L_E-DFT_E)),
 ('Aligned energy MAE',np.abs(U_E-off-DFT_E),np.abs(L_E-off-DFT_E)),
 ('H force MAE',per['U0_H_force_mae_eV_A'].to_numpy(),per['Full_LoRA_H_force_mae_eV_A'].to_numpy()),
 ('Cu force MAE',per['U0_Cu_force_mae_eV_A'].to_numpy(),per['Full_LoRA_Cu_force_mae_eV_A'].to_numpy()),
]:
    idx=np.concatenate([rng.choice(cu_idx,(BB,len(cu_idx)),replace=True),rng.choice(h2_idx,(BB,len(h2_idx)),replace=True)],axis=1)
    if met=='H force MAE':
        bs_u=np.nanmean(u[idx],axis=1);bs_l=np.nanmean(l[idx],axis=1)
    else:
        bs_u=np.mean(u[idx],axis=1);bs_l=np.mean(l[idx],axis=1)
    delta=bs_u-bs_l; rel=100*delta/bs_u
    ci.append(dict(metric=met,U0_MAE=float(np.nanmean(u)),Full_LoRA_MAE=float(np.nanmean(l)),
                   gain=float(np.nanmean(u)-np.nanmean(l)),improvement_percent=float(100*(np.nanmean(u)-np.nanmean(l))/np.nanmean(u)),
                   gain_ci_2p5=float(np.quantile(delta,.025)),gain_ci_97p5=float(np.quantile(delta,.975)),
                   improvement_ci_2p5=float(np.quantile(rel,.025)),improvement_ci_97p5=float(np.quantile(rel,.975)),
                   paired_positive_bootstrap_fraction=float(np.mean(delta>0))))
ci_df=pd.DataFrame(ci); ci_df.to_csv(TAB/'paired_bootstrap_95ci.csv',index=False)

bycomp=[]
for c in ['Cu54','Cu54H2']:
 q=comp==c
 for model,e in [('Frozen U0',U_E),('Full LoRA',L_E)]:
  res=e[q]-DFT_E[q]; res_a=res-off[q]
  bycomp.append({'composition':c,'model':model,'n':int(q.sum()),'raw_MAE_eV':float(np.abs(res).mean()),'raw_bias_eV':float(res.mean()),'aligned_MAE_eV':float(np.abs(res_a).mean()),'aligned_bias_eV':float(res_a.mean())})
bycomp_df=pd.DataFrame(bycomp);bycomp_df.to_csv(TAB/'energy_by_composition.csv',index=False)

# Within-composition relative energy; fixed first-in-file reference per composition.
rel_info=[]; rel_DFT=np.zeros(len(frames));rel_U=np.zeros(len(frames));rel_L=np.zeros(len(frames))
for c in ['Cu54','Cu54H2']:
 idx=np.where(comp==c)[0]; base_idx=idx[0]
 for arr,rel in [(DFT_E,rel_DFT),(U_E,rel_U),(L_E,rel_L)]: rel[idx]=arr[idx]-arr[base_idx]
 for m,arr in [('Frozen U0',rel_U),('Full LoRA',rel_L)]:
  rel_info.append(dict(composition=c,reference_source_index=int(ids[base_idx]),model=m,MAE_eV=float(np.mean(np.abs(arr[idx]-rel_DFT[idx])))))
relative_df=pd.DataFrame(rel_info);relative_df.to_csv(TAB/'within_composition_relative_energy.csv',index=False)

# Additional informative counts and sensitivity metrics.
summary={
 'val_frames':len(frames),'Cu54H2_frames':int(sum(comp=='Cu54H2')),'Cu54_frames':int(sum(comp=='Cu54')),
 'total_atoms':int(len(NUM)),'H_atoms':int(sum(N_H)),'Cu_atoms':int(sum(N_CU)),
 'H_components':int(sum(N_H)*3),'Cu_components':int(sum(N_CU)*3),
 'reference_energy_range_eV':[float(DFT_E.min()),float(DFT_E.max())],
 'source_id_alignment_verified':True,'manifest_sha256_verified':True,
 'reference_calibration_offsets_eV':cal['offsets'],
 'metrics':metrics_df.to_dict('records'), 'bootstrap':ci_df.to_dict('records'),
 'by_composition':bycomp_df.to_dict('records'), 'relative_energy':relative_df.to_dict('records'),
 'configuration_improvement_counts':{
  'aligned_energy':int((np.abs(L_E-off-DFT_E)<np.abs(U_E-off-DFT_E)).sum()),
  'raw_energy':int((np.abs(L_E-DFT_E)<np.abs(U_E-DFT_E)).sum()),
  'H_force':int(((per['Full_LoRA_H_force_mae_eV_A']<per['U0_H_force_mae_eV_A']) & per['Full_LoRA_H_force_mae_eV_A'].notna()).sum()),
  'Cu_force':int((per['Full_LoRA_Cu_force_mae_eV_A']<per['U0_Cu_force_mae_eV_A']).sum())},
 'nonzero_val_losses':int(train.validation_loss.notna().sum()) if 'validation_loss' in train else None}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))

# FIGURE 1: Three-way raw absolute energy comparison by composition.
fig,ax=plt.subplots(1,2,figsize=(12.6,5.2),sharex=False,sharey=False)
for j,c in enumerate(['Cu54','Cu54H2']):
 q=(comp==c)
 lo=min(DFT_E[q].min(),U_E[q].min(),L_E[q].min())-.35; hi=max(DFT_E[q].max(),U_E[q].max(),L_E[q].max())+.35
 ax[j].plot([lo,hi],[lo,hi],color=SLATE,lw=1.6,ls='--',label='DFT identity line',zorder=1)
 ax[j].scatter(DFT_E[q],U_E[q],s=46,alpha=.73,color=ORANGE,label='Frozen U0',edgecolor='white',lw=.25,zorder=3)
 ax[j].scatter(DFT_E[q],L_E[q],s=37,alpha=.83,color=TEAL,label='Full LoRA',marker='D',edgecolor='white',lw=.25,zorder=4)
 ax[j].set_xlim(lo,hi); ax[j].set_ylim(lo,hi);ax[j].set_aspect('equal','box')
 ax[j].set_title(f'{c}  (n={q.sum()} configurations)')
 ax[j].set_xlabel('DFT reference energy  (eV/config)')
 if j==0:ax[j].set_ylabel('Model-predicted energy  (eV/config)')
 ax[j].grid(alpha=.3,color=GRID)
 ax[j].text(.035,.96,f'U0 MAE  {np.abs(U_E[q]-DFT_E[q]).mean():.3f} eV\nL-All MAE  {np.abs(L_E[q]-DFT_E[q]).mean():.3f} eV',
            transform=ax[j].transAxes,va='top',ha='left',fontsize=9.5,bbox=dict(facecolor='white',alpha=.82,edgecolor='none',boxstyle='round,pad=.35'))
handles,labels=ax[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,1.01),ncol=3,frameon=False)
fig.suptitle('Three-way comparison | Absolute total energies',y=1.075,fontsize=15,fontweight='bold')
fig.tight_layout(rect=[0,0,1,.98]);save(fig,'01_energy_raw_parity_by_composition')

# FIG 2: aligned energy comparison per composition, same fixed U0 offset.
fig,ax=plt.subplots(1,2,figsize=(12.6,5.2),sharex=False,sharey=False)
for j,c in enumerate(['Cu54','Cu54H2']):
 q=comp==c
 u=U_E-off; l=L_E-off
 lo=min(DFT_E[q].min(),u[q].min(),l[q].min())-.3;hi=max(DFT_E[q].max(),u[q].max(),l[q].max())+.3
 ax[j].plot([lo,hi],[lo,hi],color=SLATE,lw=1.5,ls='--',label='DFT reference')
 ax[j].scatter(DFT_E[q],u[q],s=46,alpha=.72,color=ORANGE,label='U0, aligned')
 ax[j].scatter(DFT_E[q],l[q],s=36,marker='D',alpha=.87,color=TEAL,label='Full LoRA, aligned')
 ax[j].set_xlim(lo,hi);ax[j].set_ylim(lo,hi);ax[j].set_aspect('equal','box');ax[j].grid(alpha=.30,color=GRID)
 ax[j].set_title(f'{c}: fixed offset  {off[q][0]:+.3f} eV')
 ax[j].set_xlabel('DFT reference energy  (eV/config)')
 if j==0:ax[j].set_ylabel('Offset-corrected prediction  (eV/config)')
 ax[j].text(.04,.96,f'U0 MAE  {np.abs(u[q]-DFT_E[q]).mean():.3f} eV\nL-All MAE  {np.abs(l[q]-DFT_E[q]).mean():.3f} eV',transform=ax[j].transAxes,
            va='top',fontsize=9.5,bbox=dict(facecolor='white',alpha=.85,edgecolor='none',boxstyle='round,pad=.35'))
handles,labels=ax[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,1.01),ncol=3,frameon=False)
fig.suptitle('Three-way comparison | Aligned energies (no validation fitting)',y=1.075,fontsize=15,fontweight='bold');fig.tight_layout(rect=[0,0,1,.98]);save(fig,'02_energy_aligned_parity_by_composition')

# FIG 3: residual distribution, both raw and aligned, decomposition by composition.
fig,axes=plt.subplots(2,2,figsize=(12.8,8.0),sharex='row',sharey='row')
for r,typ in enumerate(['Raw','Aligned']):
 for j,c in enumerate(['Cu54','Cu54H2']):
  ax=axes[r,j];q=(comp==c)
  uu=U_E[q]-DFT_E[q]-(off[q] if r==1 else 0); ll=L_E[q]-DFT_E[q]-(off[q] if r==1 else 0)
  bins=np.linspace(min(uu.min(),ll.min())-.07,max(uu.max(),ll.max())+.07,14)
  ax.hist(uu,bins=bins,alpha=.57,color=ORANGE,label='Frozen U0')
  ax.hist(ll,bins=bins,alpha=.64,color=TEAL,label='Full LoRA')
  ax.axvline(0,color=SLATE,lw=1.4,linestyle='--')
  ax.set_title(f'{c} | {typ.lower()} energy residual')
  ax.set_xlabel('Predicted minus DFT  (eV/config)')
  if j==0:ax.set_ylabel('Number of configurations')
  ax.grid(alpha=.22,axis='y',color=GRID)
  ax.text(.03,.95,f'U0 bias {uu.mean():+.3f} eV\nL-All bias {ll.mean():+.3f} eV',transform=ax.transAxes,va='top',fontsize=9,bbox=dict(facecolor='white',alpha=.80,edgecolor='none'))
fig.legend(handles=[plt.Line2D([],[],color=ORANGE,lw=6),plt.Line2D([],[],color=TEAL,lw=6)],labels=['Frozen U0','Full LoRA'],loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.5,1.015))
fig.suptitle('Energy residual distributions reveal composition-dependent bias',y=1.065,fontsize=15,fontweight='bold');fig.tight_layout(rect=[0,0,1,.99]);save(fig,'03_energy_residuals_raw_vs_aligned')

# FIG 4: H parity, full ranges with magnified [-1,1] insets to expose shape.
fig,axes=plt.subplots(1,2,figsize=(12.4,5.5))
for j,(name,force,col) in enumerate([('Frozen U0',U_F,ORANGE),('Full LoRA',L_F,TEAL)]):
 d=DFT_F[N_H].reshape(-1);p=force[N_H].reshape(-1)
 axes[j].scatter(d,p,s=22,c=col,alpha=.65,linewidths=0)
 lim=max(np.max(np.abs(d)),np.max(np.abs(p)))*1.055
 axes[j].plot([-lim,lim],[-lim,lim],linestyle='--',color=SLATE,lw=1.5)
 axes[j].set_xlim(-lim,lim);axes[j].set_ylim(-lim,lim);axes[j].set_aspect('equal','box');axes[j].grid(color=GRID,alpha=.4)
 axes[j].set_title(f'{name} | MAE {np.mean(np.abs(p-d)):.4f} eV/Å')
 axes[j].set_xlabel('DFT H force component  (eV/Å)')
 if j==0:axes[j].set_ylabel('Predicted H force component  (eV/Å)')
 from mpl_toolkits.axes_grid1.inset_locator import inset_axes
 ins=inset_axes(axes[j],width='42%',height='42%',loc='lower right',borderpad=1)
 ins.scatter(d,p,s=8,color=col,alpha=.44,linewidths=0)
 ins.plot([-1,1],[-1,1],color=SLATE,linestyle='--',lw=1)
 ins.set_xlim(-1,1); ins.set_ylim(-1,1);ins.set_xticks([-1,0,1]);ins.set_yticks([-1,0,1]);ins.tick_params(labelsize=7);ins.set_facecolor('white')
fig.suptitle('DFT reference vs predicted H force components  (n = 384)',fontsize=15,y=1.02,fontweight='bold');fig.tight_layout();save(fig,'04_H_force_component_parity')

# FIG 5: Cu parity with density color as 16k components per model; scatter subsample equally deterministic.
fig,axes=plt.subplots(1,2,figsize=(12.4,5.6))
d=DFT_F[N_CU].reshape(-1)
for j,(name,force,col) in enumerate([('Frozen U0',U_F,ORANGE),('Full LoRA',L_F,TEAL)]):
 p=force[N_CU].reshape(-1)
 axes[j].hexbin(d,p,gridsize=70,extent=(-3.4,3.4,-3.4,3.4),mincnt=1,cmap='YlOrBr' if j==0 else 'PuBuGn',bins='log',linewidths=0)
 axes[j].plot([-3.4,3.4],[-3.4,3.4],color=SLATE,lw=1.35,ls='--')
 axes[j].set_xlim(-3.4,3.4);axes[j].set_ylim(-3.4,3.4);axes[j].set_aspect('equal','box')
 axes[j].set_xlabel('DFT Cu force component  (eV/Å)')
 if j==0:axes[j].set_ylabel('Predicted Cu force component  (eV/Å)')
 axes[j].set_title(f'{name} | MAE {np.mean(np.abs(p-d)):.4f} eV/Å')
fig.suptitle('DFT reference vs predicted Cu forces  (n = 16,200 components)',y=1.025,fontsize=15,fontweight='bold');fig.tight_layout();save(fig,'05_Cu_force_density_parity')

# FIG 6: force absolute-error cumulative distributions H/Cu (model and DFT reference context).
fig,axes=plt.subplots(1,2,figsize=(12.2,4.65))
for j,(name,mask) in enumerate([('Hydrogen',N_H),('Copper',N_CU)]):
 for label,p,color in [('Frozen U0',U_F,ORANGE),('Full LoRA',L_F,TEAL)]:
  err=np.abs(p[mask]-DFT_F[mask]).ravel()
  xs=np.sort(np.maximum(err,1e-7));ys=np.arange(1,len(xs)+1)/len(xs)
  axes[j].plot(xs,ys,label=label,color=color,lw=2.1)
 axes[j].set_xscale('log');axes[j].set_xlabel('|Predicted - DFT force component|  (eV/Å)');axes[j].set_ylabel('Fraction of components below error');axes[j].set_title(name)
 axes[j].grid(alpha=.28,color=GRID);axes[j].set_ylim(0,1.03)
 axes[j].legend(frameon=False,loc='lower right',fontsize=9)
fig.suptitle('Force-component error distributions relative to DFT',y=1.05,fontsize=15,fontweight='bold');fig.tight_layout();save(fig,'06_force_error_cdf')

# FIG 7: paired per-frame improvement: same frame U0 vs L-All, DFT as shared reference.
fig,axes=plt.subplots(1,3,figsize=(15.0,4.9))
for j,(name,ucol,lcol,unit) in enumerate([
 ('Aligned energy',np.abs(U_E-off-DFT_E),np.abs(L_E-off-DFT_E),'eV/config'),
 ('H force',per['U0_H_force_mae_eV_A'].to_numpy(),per['Full_LoRA_H_force_mae_eV_A'].to_numpy(),'eV/Å'),
 ('Cu force',per['U0_Cu_force_mae_eV_A'].to_numpy(),per['Full_LoRA_Cu_force_mae_eV_A'].to_numpy(),'eV/Å')]):
 mask=np.isfinite(ucol)&np.isfinite(lcol);xx=ucol[mask]; yy=lcol[mask]
 if j==0:
  for c,marker,color in [('Cu54','o',ORANGE),('Cu54H2','D',TEAL)]:
   m=(comp==c)&mask;axes[j].scatter(ucol[m],lcol[m],label=c,s=29,alpha=.74,marker=marker,color=color)
  axes[j].legend(frameon=False,fontsize=9)
 else:axes[j].scatter(xx,yy,s=24,alpha=.72,c=TEAL if j==2 else ORANGE)
 lim=max(xx.max(),yy.max())*1.07;axes[j].plot([0,lim],[0,lim],color=SLATE,linestyle='--',lw=1.35)
 axes[j].set_xlim(0,lim);axes[j].set_ylim(0,lim);axes[j].set_aspect('equal','box');axes[j].grid(color=GRID,alpha=.25)
 axes[j].set_xlabel('Frozen U0 frame MAE  ('+unit+')')
 if j==0:axes[j].set_ylabel('Full LoRA frame MAE  ('+unit+')')
 axes[j].set_title(name+f' | improved {int((yy<xx).sum())}/{len(xx)}')
fig.suptitle('Paired per-configuration errors against the same DFT labels',y=1.035,fontsize=14.5,fontweight='bold');fig.tight_layout();save(fig,'07_per_configuration_paired_errors')

# FIG 8: summary with DFT ground truth encoded as zero error line and U0/LoRA point estimates, CIs for paired gain.
fig,axes=plt.subplots(1,4,figsize=(15.1,4.7))
for j,metric in enumerate(['Raw energy MAE','Aligned energy MAE','H force MAE','Cu force MAE']):
 sub=metrics_df[metrics_df.metric==metric];v0=float(sub[sub.model=='Frozen U0'].MAE.iloc[0]);v1=float(sub[sub.model=='Full LoRA'].MAE.iloc[0]);
 axes[j].bar([0,1],[v0,v1],color=[ORANGE,TEAL],width=.61,alpha=.92)
 axes[j].axhline(0,color=SLATE,lw=1.4)
 axes[j].set_xticks([0,1],['Frozen\nU0','Full\nLoRA']);axes[j].set_ylim(0,max(v0,v1)*1.30)
 for k,v in enumerate([v0,v1]):axes[j].text(k,v+max(v0,v1)*.03,f'{v:.4f}',ha='center',fontsize=9.5,fontweight='bold')
 imp=(1-v1/v0)*100; axes[j].set_title(metric+f'\n{imp:+.1f}% error reduction',fontsize=10.5)
 axes[j].set_ylabel('MAE (eV/config)' if j<2 else 'MAE (eV/Å/component)');axes[j].grid(axis='y',color=GRID,alpha=.28)
fig.suptitle('DFT reference is the zero-error target | U0 versus Full LoRA',y=1.045,fontsize=15,fontweight='bold');fig.tight_layout();save(fig,'08_reference_based_mae_summary')

# FIG 9: normalized objective training / validation trends, extracted from run logs.
fig,axes=plt.subplots(1,2,figsize=(12.9,4.75))
tr=train.copy();tr['rolling_median']=tr.train_loss.rolling(101,center=True,min_periods=25).median()
axes[0].scatter(tr.step,tr.train_loss,s=4,color=ORANGE,alpha=.27,label='Per-update loss')
axes[0].plot(tr.step,tr.rolling_median,color=TEAL,lw=2,label='101-step rolling median')
axes[0].set_yscale('log');axes[0].set_xlabel('Optimizer update');axes[0].set_ylabel('Normalized training loss (log scale)');axes[0].set_title('Training: 500 frames x 4 passes');axes[0].legend(frameon=False,fontsize=9);axes[0].grid(color=GRID,alpha=.23)
val=tr.dropna(subset=['val_loss'])[['step','val_loss']] if 'val_loss' in tr else pd.DataFrame()
if val.empty:val=tr.dropna(subset=['validation_loss'])[['step','validation_loss']].rename(columns={'validation_loss':'val_loss'})
axes[1].plot(val.step,val.val_loss,color=TEAL,marker='o',markersize=6,lw=2)
axes[1].set_xlabel('Optimizer update');axes[1].set_ylabel('Normalized validation loss');axes[1].set_title('Validation: 100 frames, every 250 updates');axes[1].grid(color=GRID,alpha=.3)
for x,y in zip(val.step,val.val_loss):
 if x in (250,1000,2000):axes[1].annotate(f'{y:.3f}',(x,y),xytext=(0,9),textcoords='offset points',ha='center',fontsize=8.5)
fig.suptitle('Optimization dynamics | Full LoRA, rank 2, seed 41',y=1.055,fontsize=15,fontweight='bold');fig.tight_layout();save(fig,'09_training_and_validation_convergence')

# FIG 10: relative energy within composition, subtract a predeclared frame reference.
fig,axes=plt.subplots(1,2,figsize=(12.8,5.15))
for j,c in enumerate(['Cu54','Cu54H2']):
 q=(comp==c);dd=rel_DFT[q];uu=rel_U[q];ll=rel_L[q];mi=min(dd.min(),uu.min(),ll.min())-.25;ma=max(dd.max(),uu.max(),ll.max())+.25
 axes[j].plot([mi,ma],[mi,ma],color=SLATE,linestyle='--',lw=1.5,label='DFT identity line')
 axes[j].scatter(dd,uu,s=42,color=ORANGE,alpha=.72,label='Frozen U0')
 axes[j].scatter(dd,ll,s=38,color=TEAL,alpha=.82,marker='D',label='Full LoRA')
 axes[j].set_xlim(mi,ma);axes[j].set_ylim(mi,ma);axes[j].set_aspect('equal','box');axes[j].grid(alpha=.24,color=GRID)
 ref=int(ids[np.where(q)[0][0]])
 axes[j].set_title(f'{c} | reference source_index {ref}')
 axes[j].set_xlabel('DFT relative energy  (eV)')
 if j==0:axes[j].set_ylabel('Predicted relative energy  (eV)')
 u_mae=np.mean(np.abs(uu-dd));l_mae=np.mean(np.abs(ll-dd))
 axes[j].text(.035,.96,f'U0 MAE  {u_mae:.3f} eV\nL-All MAE  {l_mae:.3f} eV',transform=axes[j].transAxes,va='top',fontsize=9.5,bbox=dict(facecolor='white',alpha=.85,edgecolor='none'))
handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,1.01),ncol=3,frameon=False)
fig.suptitle('Within-composition relative energies (no fitted offset)',y=1.07,fontsize=15,fontweight='bold');fig.tight_layout(rect=[0,0,1,.985]);save(fig,'10_within_composition_relative_energy')

# FIG 11: individual force-component absolute error vs DFT magnitude; model point estimates by quantile bin.
fig,axes=plt.subplots(1,2,figsize=(12.8,4.9))
for j,(name,mask) in enumerate([('Hydrogen',N_H),('Copper',N_CU)]):
 mag=np.abs(DFT_F[mask].reshape(-1));
 # Force magnitudes bin by DFT abs value, robust edge selection.
 boundaries=np.unique(np.quantile(mag,np.linspace(0,1,9)))
 for lab,arr,col in [('Frozen U0',U_F,ORANGE),('Full LoRA',L_F,TEAL)]:
  err=np.abs(arr[mask]-DFT_F[mask]).ravel(); x=[];y=[]
  for k in range(len(boundaries)-1):
   m=(mag>=boundaries[k]) & ((mag<boundaries[k+1]) if k<len(boundaries)-2 else (mag<=boundaries[k+1]))
   if m.any():x.append(np.median(mag[m]));y.append(float(np.mean(err[m])))
  axes[j].plot(x,y,'o-',color=col,label=lab,lw=1.9,markersize=5)
 axes[j].set_xscale('symlog',linthresh=.015) # handles near-zero DFT force components
 axes[j].set_xlabel('|DFT force component| (eV/Å)')
 axes[j].set_ylabel('Binned mean absolute error  (eV/Å)')
 axes[j].set_title(f'{name} | eight quantile bins')
 axes[j].grid(alpha=.3,color=GRID);axes[j].legend(frameon=False,fontsize=9)
fig.suptitle('Error as a function of DFT force magnitude',y=1.05,fontsize=15,fontweight='bold');fig.tight_layout();save(fig,'11_force_error_by_reference_magnitude')

print('SUCCESS')
print('metrics:\n',metrics_df.to_string(index=False))
print('CI:\n',ci_df.round(4).to_string(index=False))
print('energy per comp:\n',bycomp_df.round(4).to_string(index=False))
print('relative:\n',relative_df.round(4).to_string(index=False))
print('counts:',summary['configuration_improvement_counts'])
print('validation points:\n',val.to_string(index=False))
