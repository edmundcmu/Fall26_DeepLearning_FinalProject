import io,json,zipfile,hashlib,re,numpy as np, pandas as pd
from pathlib import Path
OUT=Path('/mnt/data/UMA_Three_Way_Comparison')
with zipfile.ZipFile('/mnt/data/i-x20.zip') as z:
    b='i-x20/uma_cuh_baseline/data/prepared/'
    raw=z.read(b+'val/structures.extxyz')
    manifest=json.loads(z.read(b+'manifest.json'))
    print('DFT SHA256 matches manifest:',hashlib.sha256(raw).hexdigest()==manifest['file_sha256']['val'])
    # The uploaded file is a straightforward extended XYZ with species, coordinates and forces.
    # Parse its stored DFT labels without requiring ASE or running any model.
    lines=raw.decode().splitlines(); frames=[]; cursor=0
    while cursor < len(lines):
        n=int(lines[cursor].strip()); header=lines[cursor+1]
        en=float(re.search(r'\benergy=([^ ]+)',header).group(1))
        sid=int(re.search(r'\bsource_index=(\d+)',header).group(1))
        atoms=[line.split() for line in lines[cursor+2:cursor+2+n]]
        species_text=np.array([a[0] for a in atoms]); f=np.array([[float(x) for x in a[-3:]] for a in atoms]); pos=np.array([[float(x) for x in a[1:4]] for a in atoms])
        frames.append({'energy':en,'source_index':sid,'numbers':np.where(species_text=='H',1,29), 'forces':f, 'pos':pos})
        cursor += n+2
with zipfile.ZipFile('/mnt/data/UMA_LAll_results_seed41.zip') as z:
    b='UMA_LAll_results_seed41/runs/lall/full_training_seed41/'
    lall=np.load(io.BytesIO(z.read(b+'val_predictions.npz')))
    vmetrics=json.loads(z.read(b+'validation_metrics.json'))
    trainlogs=[json.loads(x) for x in z.read(b+'training.jsonl').decode().splitlines() if x.strip()]
    print('training log entries',len(trainlogs))
u0=np.load('/mnt/data/val_predictions(2).npz')
metrics=json.loads(Path('/mnt/data/metrics(1).json').read_text())
source=np.array([int(f['source_index']) for f in frames],dtype=int)
print('source indices align?',np.array_equal(source,u0['source_index']), np.array_equal(source,lall['source_index']))
print('offset arrays match',np.array_equal(u0['offsets'],lall['offsets']))
assert len(frames)==100 and np.array_equal(source,u0['source_index']) and np.array_equal(source,lall['source_index'])
assert np.array_equal(u0['offsets'],lall['offsets'])
assert all(u0['offsets'][i+1]-u0['offsets'][i]==len(f["numbers"]) for i,f in enumerate(frames))
assert len(trainlogs)==2000
E_dft=np.array([f["energy"] for f in frames]);
F_dft=np.concatenate([f["forces"] for f in frames]);
species=np.concatenate([f["numbers"] for f in frames])
comp=np.array(['Cu54H2' if np.sum(f["numbers"]==1)==2 else 'Cu54' for f in frames])
Ue=u0['energy'];Le=lall['energy']; Uf=u0['forces']; Lf=lall['forces'];
cal=json.loads(Path('/mnt/data/UMA_Full_LoRA_Analysis/data/calibration.json').read_text())
print('cal', cal)
# load train-fitted corrections. lall metrics reportedly use same
keys={'Cu54':'54,0','Cu54H2':'54,2'}
corrections=np.array([cal['offsets'][keys[x]] for x in comp])

def metric(e,f):
    return {'raw':np.mean(np.abs(e-E_dft)),
     'aligned':np.mean(np.abs(e-corrections-E_dft)),
     'H':np.mean(np.abs(f[species==1]-F_dft[species==1])),
     'Cu':np.mean(np.abs(f[species==29]-F_dft[species==29]))}
print('counts',np.unique(comp,return_counts=True));
print('dft E range',E_dft.min(),E_dft.max(),'H force range',F_dft[species==1].min(),F_dft[species==1].max(),'Cu',F_dft[species==29].min(),F_dft[species==29].max())
for key,e,f in [('U0',Ue,Uf),('LAll',Le,Lf)]:
    m=metric(e,f);print(key,m,'diffs',[(n,m[n]-vmetrics['U0' if key=='U0' else 'L_All'][{'raw':'energy_raw_MAE_eV','aligned':'energy_aligned_MAE_eV','H':'H_force_component_MAE_eV_per_A','Cu':'Cu_force_component_MAE_eV_per_A'}[n]]) for n in m]);
    for c in ['Cu54','Cu54H2']:
        q=comp==c
        print('comp',c,'N',q.sum(),'avg raw error',np.mean(e[q]-E_dft[q]),'aligned mean err',np.mean((e-corrections-E_dft)[q]), 'MAE raw',np.abs(e[q]-E_dft[q]).mean(),'MAE aligned',np.abs(e[q]-corrections[q]-E_dft[q]).mean())
print('differences energy',np.mean(Le-Ue),np.median(Le-Ue), 'DFT', E_dft[:7]);
print('dft methods headers',frames[0])
