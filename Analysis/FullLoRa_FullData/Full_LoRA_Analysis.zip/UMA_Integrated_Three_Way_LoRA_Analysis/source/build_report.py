"""Build the report from three-way validated outputs and generated plots."""
import json, math
from pathlib import Path
import pandas as pd
from PIL import Image as PILImage
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_LEFT,TA_CENTER
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak,KeepTogether,HRFlowable

ROOT=Path(__file__).resolve().parents[1];FIG=ROOT/'figures';TAB=ROOT/'tables';
OUT=ROOT/'DFT_U0_Full_LoRA_Integrated_Report.pdf'
regular='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('DVS',regular));pdfmetrics.registerFont(TTFont('DVS-Bold',bold))

INK=colors.HexColor('#1F2C37');STEEL=colors.HexColor('#5D6F7C');TEAL=colors.HexColor('#087E85');ORANGE=colors.HexColor('#D17B38');LINE=colors.HexColor('#D9E4E8');BG=colors.HexColor('#F4F8FA');
S={
 'title':ParagraphStyle('title',fontName='DVS-Bold',fontSize=22,leading=28,textColor=INK,spaceAfter=8),
 'subtitle':ParagraphStyle('subtitle',fontName='DVS',fontSize=10.5,leading=15.5,textColor=STEEL,spaceAfter=12),
 'h1':ParagraphStyle('h1',fontName='DVS-Bold',fontSize=15.2,leading=19.7,textColor=INK,spaceAfter=10,spaceBefore=1),
 'h2':ParagraphStyle('h2',fontName='DVS-Bold',fontSize=10.7,leading=15,textColor=INK,spaceBefore=8,spaceAfter=5),
 'body':ParagraphStyle('body',fontName='DVS',fontSize=8.55,leading=13.4,textColor=INK,spaceAfter=7),
 'small':ParagraphStyle('small',fontName='DVS',fontSize=7.9,leading=12,textColor=INK,spaceAfter=5),
 'caption':ParagraphStyle('caption',fontName='DVS',fontSize=7.2,leading=10.5,textColor=STEEL,spaceAfter=9),
 'note':ParagraphStyle('note',fontName='DVS',fontSize=7.5,leading=11.3,textColor=STEEL,spaceAfter=5),
 't_head':ParagraphStyle('t_head',fontName='DVS-Bold',fontSize=7.7,leading=10.9,textColor=INK),
 't_text':ParagraphStyle('t_text',fontName='DVS',fontSize=7.5,leading=10.9,textColor=INK),
 'key':ParagraphStyle('key',fontName='DVS-Bold',fontSize=8.7,leading=13.1,textColor=INK,spaceAfter=7),
}
W,H=letter;left=46;right=46; top=57; bottom=50; avail=W-left-right
D=SimpleDocTemplate(str(OUT),pagesize=letter,rightMargin=right,leftMargin=left,topMargin=top,bottomMargin=bottom,title='DFT Reference vs Frozen UMA U0 vs Full LoRA | Integrated Validation and Training Analysis',author='Analysis prepared from provided DFT, U0, and LoRA prediction files',subject='Paired 100-configuration validation comparison')

story=[]
P=lambda tx,style='body':Paragraph(tx,S[style]);
def t(data,widths=None,fontsize=7.5,header=True):
  parsed=[]
  for i,row in enumerate(data):
    parsed.append([P(str(v),'t_head' if i==0 and header else 't_text') for v in row])
  tt=Table(parsed,colWidths=widths,repeatRows=(1 if header else 0),hAlign='LEFT',spaceAfter=9)
  styles=[('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,0),.8,LINE),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,BG]),('LINEBELOW',(0,-1),(-1,-1),.5,LINE)]
  if header:styles.append(('BACKGROUND',(0,0),(-1,0),BG))
  tt.setStyle(TableStyle(styles));return tt

def fig(fname,desired_width=avail):
 im=PILImage.open(FIG/fname); a=im.width/im.height
 return Image(str(FIG/fname),width=desired_width,height=desired_width/a,hAlign='CENTER')

def title(tit,kicker):
 story.append(P(kicker.upper(),'note'));story.append(P(tit,'h1'))

def cap(s): story.append(P(s,'caption'))

def note(s):story.append(P(s,'note'))

def pg():story.append(PageBreak())

# 1 - executive summary
story.append(P('COMPUTATIONAL MATERIALS | MODEL ADAPTATION STUDY','note'))
story.append(P('DFT Reference vs Frozen U0<br/>vs Full LoRA','title'))
story.append(P('A source-aligned, three-way Cu/H comparison with training convergence and six-group adapter-budget analysis | 100 validation structures | 2,000 updates','subtitle'))
story.append(P('<b>Scope:</b> The original DFT labels are the numerical reference. Frozen U0 is the unchanged pretrained UMA-M-1.1 predictor. Full LoRA uses the six candidate adapter groups with 343,040 trained parameters. All model outputs are paired to identical DFT structures and force components.','body'))
story.append(t([
 ['Observable','DFT reference','Frozen U0 MAE','Full LoRA MAE','Error change'],
 ['Raw total energy','Original energy','1.3909 eV/config','1.4649 eV/config','5.3% worse'],
 ['Aligned energy','Same DFT energy','0.5411 eV/config','0.2494 eV/config','53.9% lower'],
 ['Hydrogen force','Original F(x,y,z)','0.03265 eV/A','0.01811 eV/A','44.5% lower'],
 ['Copper force','Original F(x,y,z)','0.01978 eV/A','0.00654 eV/A','66.9% lower'],
],widths=[96,105,109,110,100]))
story.append(fig('08_reference_based_mae_summary.png',desired_width=508))
cap('Figure 1. Error against the same DFT reference. DFT is the zero-residual reference, not a separately evaluated prediction. Energy errors use eV/configuration; force errors are Cartesian-component MAEs in eV/A.')
story.append(P('<b>Main finding.</b> Full LoRA substantially reduces H and Cu force errors and the fixed-offset aligned energy error. It does <b>not</b> improve raw total-energy MAE. The apparent disagreement is composition-dependent, not a numerical inconsistency.','body'))
story.append(P('<b>Validation only.</b> This split was used for checkpoint selection; the sealed test set has not been evaluated. These results establish a strong benchmark for the next parameter-matched adapter-selection experiments, not final generalization.','small'))
pg()

# 2 parity energy
# 2 - Energy parity

title('Total-energy predictions against DFT','01 / ENERGY PARITY')
story.append(P('The panels separate Cu54 (36 structures) and Cu54H2 (64 structures), because these compositions have different absolute energies and distinct systematic model errors. DFT is the dashed y = x identity line.','body'))
story.append(fig('01_energy_raw_parity_by_composition.png',desired_width=448))
cap('Figure 2. Uncorrected DFT, U0 and Full LoRA total energies. Full LoRA is closer to DFT for bare Cu54, but farther for Cu54H2 in raw absolute energy.')
story.append(fig('02_energy_aligned_parity_by_composition.png',desired_width=448))
cap('Figure 3. The same predictions after subtracting composition-specific U0 residual offsets fitted only on the training set: -0.142832 eV for Cu54 and -2.463651 eV for Cu54H2.')
story.append(P('<b>Interpretation.</b> The aligned comparison isolates performance under the project\'s fixed energy-calibration protocol; it is not a new validation-fitted correction. Both compositions become closer to the DFT line after fine-tuning, but a claim of improved <i>absolute</i> energies would contradict the raw Cu54H2 result.','body'))
pg()

# 3 - composition-wise residuals

title('Why raw and aligned energy tell different stories','02 / ENERGY ERROR DECOMPOSITION')
story.append(P('The discrepancy arises because the fine-tuned model shifts the raw-energy prediction downward by approximately 0.292 eV/configuration on average. This reduces the positive Cu54 bias but increases the negative Cu54H2 bias.','body'))
story.append(fig('03_energy_residuals_raw_vs_aligned.png',desired_width=480))
cap('Figure 4. Histograms of signed (predicted - DFT) total-energy residuals, separated by composition. Dashed vertical lines indicate zero error. No validation offset was optimized.')
story.append(t([
 ['Composition / n','Model','Raw MAE (eV)','Raw bias (eV)','Aligned MAE (eV)'],
 ['Cu54 / 36','Frozen U0','0.4220','+0.4220','0.5648'],
 ['Cu54 / 36','Full LoRA','0.1196','+0.1196','0.2624'],
 ['Cu54H2 / 64','Frozen U0','1.9359','-1.9359','0.5278'],
 ['Cu54H2 / 64','Full LoRA','2.2216','-2.2216','0.2420'],
],widths=[106,92,104,108,110]))
story.append(P('<b>Critical distinction.</b> All 100 aligned energy errors improve in this set, but only 36 of 100 raw absolute-energy errors improve. This is not a contradiction: the fixed U0 offsets differ by 2.32 eV across the two compositions. The evaluation therefore needs to report both raw and aligned results.','body'))
pg()

# 4 - force parity

title('Atomic forces: DFT versus U0 and Full LoRA','03 / FORCE PARITY')
story.append(P('Forces are compared component by component against the original DFT vectors, with identical atomic order within each structure. The reference dataset contains 128 H atoms (384 Cartesian components) and 5,400 Cu atoms (16,200 components).','body'))
story.append(fig('04_H_force_component_parity.png',desired_width=448))
cap('Figure 5. Hydrogen force-component parity. The full force range hides many small discrepancies, so both panels include an enlarged central region. U0 MAE: 0.03265 eV/A; Full LoRA: 0.01811 eV/A.')
story.append(fig('05_Cu_force_density_parity.png',desired_width=448))
cap('Figure 6. Copper force-component parity, shown as density maps to avoid overplotting 16,200 components. U0 MAE: 0.01978 eV/A; Full LoRA: 0.00654 eV/A.')
story.append(P('<b>Interpretation.</b> The LoRA model follows the same DFT force vectors more closely for both species; the Cu-force gain is especially consistent. These plots measure accuracy on fixed configurations, not stability in molecular dynamics or force-derived rate predictions.','body'))
pg()

# 5 - distributions

title('Force-error distributions and DFT-force magnitude','04 / DETAILED FORCE BEHAVIOR')
story.append(P('A parity plot can obscure changes in small errors when the physical force range is wide. The two distributions below characterize the absolute deviation relative to DFT rather than relying solely on correlations near the identity line.','body'))
story.append(fig('06_force_error_cdf.png',desired_width=500))
cap('Figure 7. Empirical cumulative distribution of absolute force-component errors. A curve farther left / higher at a given error threshold indicates smaller errors. The Full LoRA curve dominates across most of both distributions.')
story.append(fig('11_force_error_by_reference_magnitude.png',desired_width=500))
cap('Figure 8. Mean absolute force error binned by the magnitude of the DFT force component. Eight quantile bins per element; x-axis uses a symmetric logarithmic scale near zero.')
story.append(P('<b>Physical reading.</b> H force components reach roughly +/-7.74 eV/A in this validation sample, compared with a much smaller typical force error. Thus visual agreement over the full range does not eliminate the need for a focused residual analysis. LoRA also reduces Cu errors for low- and high-force bins.','body'))
pg()

# 6 - paired configuration + bootstrap

title('Are gains widespread or driven by a few cases?','05 / PAIRED IMPROVEMENT')
story.append(P('All comparisons below are paired to exactly the same DFT-labeled structures. Each point is one configuration, not one force component; values below the dashed y = x line indicate an improvement over U0.','body'))
story.append(fig('07_per_configuration_paired_errors.png',desired_width=507))
cap('Figure 9. Full LoRA versus U0 per-configuration MAEs: aligned energy (100 frames), H forces (64 H-bearing frames), and Cu forces (100 frames). The same DFT labels define both axes.')
story.append(t([
 ['Metric','Improved frames','Reduction','Exploratory 95% CI, reduction'],
 ['Aligned energy','100 / 100','53.9%','52.8% to 55.0%'],
 ['H force','61 / 64','44.5%','39.1% to 49.8%'],
 ['Cu force','100 / 100','66.9%','66.2% to 67.6%'],
 ['Raw energy','36 / 100','-5.3%','-6.5% to -4.3%'],
],widths=[128,107,85,200]))
story.append(P('<b>Uncertainty convention.</b> Intervals use 4,000 paired, composition-stratified bootstrap resamples of validation configurations (seed 41). They are descriptive, not independent external-test confidence intervals: configurations may be related through the underlying DFT trajectory, and this same split selected the LoRA checkpoint.','body'))
story.append(P('<b>Conclusion from paired data.</b> The Cu-force gain is widespread across the validation configurations, while H-force improvements occur in 61 of the 64 relevant structures. This is stronger evidence than a lower pooled MAE alone.','small'))
pg()

# 7 - model convergence

title('Optimization: what the learning curves support','06 / TRAINING HISTORY')
story.append(P('L-All used a frozen UMA-M-1.1 backbone with rank-2 adapters across six early/late groups: R, S and A. The update budget was 2,000 optimizer steps with batch size 1 over 500 training configurations (four shuffled passes).','body'))
story.append(fig('09_training_and_validation_convergence.png',desired_width=505))
cap('Figure 10. Individual normalized training losses (log scale) and the fixed 100-frame validation objective sampled every 250 updates. The checkpoint with the lowest recorded validation loss was the final one (step 2000).')
story.append(t([
 ['Step','250','500','750','1000','1250','1500','1750','2000'],
 ['Val. loss','0.2720','0.1714','0.1281','0.1274','0.1183','0.1146','0.1051','0.1001'],
],widths=[70]+[56.25]*8))
story.append(P('<b>Convergence.</b> Normalized validation loss fell from 0.27197 at step 250 to 0.10006 at step 2000 (63.2%). The later values continued to decrease; there is no evidence from these saved checkpoints that validation performance worsened before step 2000. One high training loss from an individual structure should not be confused with a population-level divergence.','body'))
story.append(P('<b>Budget and limits.</b> Full LoRA had 343,040 trainable adapter parameters versus 1,397,012,129 original UMA parameters (about 0.0246%). The S groups represent the largest fraction of adapter capacity, and the MoLE LoRA update is expert-shared, not 32 independently trained expert adapters.','body'))
pg()

# 8 - detailed stochastic convergence: restore figure and discussion from full-LoRA report

title('Training loss: noisy updates, stable overall improvement','07 / DETAILED TRAINING CONVERGENCE')
story.append(P('The validation history on the previous page summarizes population-level progress. Here, every one of the 2,000 optimizer updates is shown separately. With batch size 1, the normalized objective is calculated on a different DFT configuration at each update, so individual losses are not measurements on a common fixed evaluation batch.','body'))
story.append(fig('12_detailed_training_loss.png',desired_width=504))
cap('Figure 11. The original Full LoRA training-loss plot, retained with its 101-update rolling median, 90th percentile and log-scaled vertical axis. Dotted lines mark boundaries between four 500-update shuffled passes.')
story.append(t([
 ['Pass / updates','Median objective','Interpretation'],
 ['1 / 1-500','0.10498','First exposure to each of the 500 configurations'],
 ['2 / 501-1000','0.02310','Lower central error after one pass'],
 ['3 / 1001-1500','0.01767','Further, more gradual improvements'],
 ['4 / 1501-2000','0.01467','Lowest median of the four passes'],
],widths=[118,105,297]))
story.append(P('<b>Convergence evidence.</b> The median loss decreased by approximately 86.0% between the first and fourth passes; 496 of 500 training configurations had lower loss at their fourth exposure than at their first. Because the curves are computed on training examples, improvement alone does not establish generalization; the independently calculated within-training-run validation history is shown on the preceding page.','small'))
story.append(P('<b>Why spikes are not automatic divergence.</b> For source_index 304, the first four exposure losses were 115.944, 73.724, 21.658 and 4.694. The large isolated value at update 50 therefore represented a particularly difficult sample whose training loss declined as learning progressed. Large residuals still warrant physical and data-quality inspection, particularly for hydrogen-containing structures.','small'))
pg()

# 9 - six group budget figure and interpretation

title('Six adapter groups: where the trainable parameters go','08 / LORA PARAMETER BUDGET')
story.append(P('Full LoRA adapts 120 matched module sites in six predefined Early/Late groups with rank 2, while the UMA backbone and output heads remain frozen. The group counts below were recovered from the saved adapter tensors, not inferred from the backbone parameter count alone.','body'))
story.append(fig('13_six_group_parameter_budget.png',desired_width=504))
cap('Figure 12. The original six-group adapter-budget plot. R, S and A denote Radial, SO(2) and Atomwise categories, respectively; Early/Late correspond to blocks 0-4 and 5-9. Parameter numbers refer to trainable LoRA matrices.')
story.append(t([
 ['Group family','Early group','Late group','Combined','Share of L-All'],
 ['R / Radial','39,680','39,680','79,360','23.1%'],
 ['S / SO(2)','99,840','99,840','199,680','58.2%'],
 ['A / Atomwise','32,000','32,000','64,000','18.7%'],
 ['TOTAL','171,520','171,520','343,040','100%'],
],widths=[107,92,91,103,127]))
story.append(P('<b>Parameter efficiency.</b> The 343,040 trainable adapter parameters correspond to approximately 0.0246% of the 1,397,012,129 original UMA parameters. S-type adapters consume most of the budget (58.2%). Counting selected groups equally would therefore not create a parameter-matched comparison. Future Selected/Random LoRA baselines should report trainable parameters, matched update/data budgets and ideally several selection seeds.','small'))
story.append(P('<b>Architectural scope.</b> The implementation uses expert-shared MoLE updates, not 32 independent LoRA matrices per expert; its S groups also include so2_conv_1 and so2_conv_2. Thus a six-group candidate-budget comparison is the correct description, not unrestricted adaptation of every UMA expert. Group sizes describe capacity, <i>not</i> empirical importance: no R-versus-S-versus-A ablation or selection result has been measured here.','small'))
pg()

# 10 - relative energy & protocol

title('Relative energies and reproducibility','09 / INTERPRETATION AND METHODS')
story.append(P('To separate changes in energy ordering from constant composition offsets, we also subtract the energy of a fixed reference configuration within each composition. The reference is the first sample in source-index order, and the same source is used for DFT, U0 and Full LoRA. This does not fit an energy offset.','body'))
story.append(fig('10_within_composition_relative_energy.png',desired_width=490))
cap('Figure 13. Within-composition relative energy, E(configuration) - E(reference). By construction, the reference point has zero error in each composition; improvement away from that point reflects better variation in predicted energies.')
story.append(t([
 ['Composition','Reference ID','Frozen U0 relative MAE','Full LoRA relative MAE'],
 ['Cu54','3925','0.0608 eV','0.0107 eV'],
 ['Cu54H2','84','0.0949 eV','0.0503 eV'],
],widths=[99,110,158,153]))
story.append(P('<b>Reference and data integrity.</b> Validation DFT energies and per-atom force vectors were extracted directly from <i>i-x20/uma_cuh_baseline/data/prepared/val/structures.extxyz</i>. The file SHA-256 matches the uploaded manifest. Predictions were taken from the uploaded U0 <i>val_predictions.npz</i> and the Full LoRA results archive; all 100 source IDs and every force offset match. The 200-frame test split was not opened.','small'))
story.append(P('<b>Energy calibration.</b> For model prediction E and fixed composition offset b from U0 training residuals, aligned error is |(E - b) - E_DFT|. The offsets are b(Cu54) = -0.142832 eV and b(Cu54H2) = -2.463651 eV. Raw MAE uses |E - E_DFT| with no correction. Force MAE is the average |F_pred - F_DFT| across Cartesian components of a specified species.','small'))
story.append(P('<b>Key limits.</b> These are validation and single-configuration predictions, not independent held-out test metrics or MD-performance guarantees. The source DFT is treated as the numerical reference; no claim about its physical accuracy versus experiment is made. Confidence intervals are exploratory because configurations may be correlated. The next scientifically decisive test is a parameter-matched comparison with selected and random LoRA adapters, followed by one locked test evaluation.','small'))

def decorate(canv,doc):
  canv.saveState();p=doc.page
  canv.setStrokeColor(LINE);canv.setLineWidth(.75)
  canv.line(left,H-40,W-right,H-40)
  canv.setFont('DVS-Bold',7.3);canv.setFillColor(TEAL)
  canv.drawString(left,H-30,'UMA-M-1.1  /  Cu-H  /  THREE-WAY VALIDATION')
  canv.setStrokeColor(LINE);canv.line(left,35,W-right,35)
  canv.setFont('DVS',7.1);canv.setFillColor(STEEL)
  canv.drawString(left,23,'DFT reference  |  Frozen U0  |  Full LoRA    •    100 configuration validation split')
  canv.drawRightString(W-right,23,f'{p:02d}')
  canv.restoreState()

D.build(story,onFirstPage=decorate,onLaterPages=decorate)
print('WROTE',OUT,OUT.stat().st_size)
